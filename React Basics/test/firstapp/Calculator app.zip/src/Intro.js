function Intro() {
    return (
        <h1>Greeting Humans!</h1>
    );
}

export default Intro;