function Header(props) {
    return (
        <h1>Hello,  {props.firstname}</h1>
    )
}

export default Header;