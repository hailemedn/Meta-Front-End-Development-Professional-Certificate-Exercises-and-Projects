function Contact() {
    return (
        <h1>Contact Little Lemon on this page</h1>
    );
}

export default Contact;