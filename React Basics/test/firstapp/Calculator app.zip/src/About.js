function About(){
    return (
        <p>More About me!</p>
    );
}

export default About;